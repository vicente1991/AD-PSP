package com.example.E01PracticaGuiadaVicenteRufo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E01PracticaGuiadaVicenteRufoApplication {

	public static void main(String[] args) {
		SpringApplication.run(E01PracticaGuiadaVicenteRufoApplication.class, args);
	}

}

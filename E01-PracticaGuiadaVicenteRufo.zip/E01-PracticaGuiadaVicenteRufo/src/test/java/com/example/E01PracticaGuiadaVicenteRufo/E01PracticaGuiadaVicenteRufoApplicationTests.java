package com.example.E01PracticaGuiadaVicenteRufo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E01PracticaGuiadaVicenteRufoApplicationTests {

	@Test
	void contextLoads() {
	}

}
